/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.instrumentanalyzer.service;

import com.instrumentanalyzer.algorithm.AlgorithmMapService;
import com.instrumentanalyzer.algorithm.DefaultAlgorithmService;
import com.instrumentanalyzer.dto.InstrumentDTO;
import com.instrumentanalyzer.enums.NoDefaultInstrumentEnum;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Service;
import java.util.stream.*;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author mar
 */
@Service
public class FileReaderService {
    
    @Autowired
    private DateParserService dateParserService;
    
    @Autowired
    private AlgorithmMapService algorithmMapService;
    
    @Autowired
    private DefaultAlgorithmService defaultAlgorithmService;

    public void readFile(MultipartFile file) throws IOException {        
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(file.getInputStream()));
            Stream<String> linesStream = bufferedReader.lines().parallel();
            linesStream.forEach(line -> {
                try {
                    String[] lineTab = line.split(",");
                    Date date = dateParserService.parseToDate(lineTab[1]);
                    if(dateParserService.isBusinessDay(date)) {
                        if(algorithmMapService.getAlgorithmForInstrument(lineTab[0])!=null) {                            
                            algorithmMapService.getAlgorithmForInstrument(lineTab[0]).addToQueue(new InstrumentDTO(lineTab[0], date, Double.valueOf(lineTab[2])));
                        } else {
                            defaultAlgorithmService.addToQueue(new InstrumentDTO(lineTab[0], date, Double.valueOf(lineTab[2])));
                        }
                    }
                } catch(Exception ex) {
                    // LOGGER
                }
            });

    }

}
