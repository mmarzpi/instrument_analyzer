/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.instrumentanalyzer.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import org.springframework.stereotype.Service;

/**
 *
 * @author mar
 */
@Service
public class DateParserService {
    
    private final DateFormat formater;

    public DateParserService() {
        this.formater = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
    }
    
    public Date parseToDate(String textDate) throws ParseException {
        return formater.parse(textDate);
    }
    
    public boolean isBusinessDay(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        return !(dayOfWeek == 6 || dayOfWeek == 7);
    }
    
}
