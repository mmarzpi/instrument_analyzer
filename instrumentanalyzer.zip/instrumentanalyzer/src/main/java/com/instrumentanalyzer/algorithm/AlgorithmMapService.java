/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.instrumentanalyzer.algorithm;

import com.instrumentanalyzer.enums.NoDefaultInstrumentEnum;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author mar
 */
@Service
public class AlgorithmMapService {

    @Autowired
    private InstrumentOneAlgorithmService instrumentOneAlgorithmService;

    @Autowired
    private InstrumentTwoAlgorithmService instrumentTwoAlgorithmService;
    
    @Autowired
    private InstrumentThreeAlgorithmService instrumentThreeAlgorithmService;

    private Map<String, AbstractInstrumentAnalyzeAlgorithm> intrumentAlgorithmMap;

    @PostConstruct
    public void init() {
        intrumentAlgorithmMap = new HashMap<>();
        intrumentAlgorithmMap.put(NoDefaultInstrumentEnum.INSTRUMENT_1.getDescription(), instrumentOneAlgorithmService);
        intrumentAlgorithmMap.put(NoDefaultInstrumentEnum.INSTRUMENT_2.getDescription(), instrumentTwoAlgorithmService);
        intrumentAlgorithmMap.put(NoDefaultInstrumentEnum.INSTRUMENT_3.getDescription(), instrumentThreeAlgorithmService);
    }

    public AbstractInstrumentAnalyzeAlgorithm getAlgorithmForInstrument(String instrumentName) {
        return intrumentAlgorithmMap.get(instrumentName);
    }

}
