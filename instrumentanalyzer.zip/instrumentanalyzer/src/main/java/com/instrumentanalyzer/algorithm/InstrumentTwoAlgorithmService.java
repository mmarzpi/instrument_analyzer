/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.instrumentanalyzer.algorithm;

import com.instrumentanalyzer.dto.InstrumentDTO;
import com.instrumentanalyzer.entity.InstrumentPriceModifier;
import com.instrumentanalyzer.enums.NoDefaultInstrumentEnum;
import com.instrumentanalyzer.repository.InstrumentPriceModifierRepository;
import com.instrumentanalyzer.service.DateParserService;
import java.text.ParseException;
import java.util.Date;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author mar
 */
@Service
public class InstrumentTwoAlgorithmService extends AbstractInstrumentAnalyzeAlgorithm {

    @Autowired
    private InstrumentPriceModifierRepository intrumentPriceModifierRepository;

    @Autowired
    private DateParserService dateParserService;

    private Date notAvailableStartDate;

    private Date notAvailableEndDate;

    @PostConstruct
    public void init() throws ParseException {
        enableAnalyzer();
        notAvailableStartDate = dateParserService.parseToDate("01-Nov-2014");
        notAvailableEndDate = dateParserService.parseToDate("30-Nov-2014");
    }

    @Override
    protected String getInstrumentName() {
        return NoDefaultInstrumentEnum.INSTRUMENT_2.getDescription();
    }

    @Override
    protected void enableAnalyzer() {
        Runnable task = () -> {
            System.out.println("Uruchomiono analizę " + getInstrumentName());
            InstrumentPriceModifier instrumentPriceModifier = null;
            while (true) {
                try {
                    if (!queue.isEmpty()) {
                        InstrumentDTO instrumentDTO = queue.poll();
                        if (!(instrumentDTO.getDate().before(notAvailableStartDate) && instrumentDTO.getDate().after(notAvailableEndDate))) {
                            instrumentPriceModifier = intrumentPriceModifierRepository.findByName(getInstrumentName());
                            if (instrumentPriceModifier == null) {
                                instrumentPriceModifier = new InstrumentPriceModifier(getInstrumentName(), instrumentDTO.getValue());
                            } else {
                                Double multiplier = Double.sum(instrumentPriceModifier.getMultiplier(), instrumentDTO.getValue());
                                instrumentPriceModifier.setMultiplier(multiplier);
                            }
                            intrumentPriceModifierRepository.save(instrumentPriceModifier);
                            Thread.sleep(instrumentModificationTimeWaiting);
                        }
                    }
                } catch (Exception ex) {
                    // LOGGER
                }
            }
        };
        Thread thread = new Thread(task);
        thread.start();
    }

}
