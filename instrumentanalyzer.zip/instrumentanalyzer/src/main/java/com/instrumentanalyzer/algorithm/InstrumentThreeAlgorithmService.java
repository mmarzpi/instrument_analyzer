/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.instrumentanalyzer.algorithm;

import com.instrumentanalyzer.dto.InstrumentDTO;
import com.instrumentanalyzer.entity.InstrumentPriceModifier;
import com.instrumentanalyzer.enums.NoDefaultInstrumentEnum;
import com.instrumentanalyzer.repository.InstrumentPriceModifierRepository;
import java.text.ParseException;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author mar
 */

@Service
public class InstrumentThreeAlgorithmService extends AbstractInstrumentAnalyzeAlgorithm {

    @Autowired
    private InstrumentPriceModifierRepository intrumentPriceModifierRepository;

    @PostConstruct
    public void init() throws ParseException {
        enableAnalyzer();
    }

    @Override
    protected String getInstrumentName() {
        return NoDefaultInstrumentEnum.INSTRUMENT_3.getDescription();
    }

    @Override
    protected void enableAnalyzer() {
        Runnable task = () -> {
            System.out.println("Uruchomiono analizę " + getInstrumentName());
            InstrumentPriceModifier instrumentPriceModifier = null;
            while (true) {
                try {
                    if (!queue.isEmpty()) {
                        InstrumentDTO instrumentDTO = queue.poll();
                        if (instrumentDTO.getValue() > 50.0) {
                            instrumentPriceModifier = intrumentPriceModifierRepository.findByName(getInstrumentName());
                            if (instrumentPriceModifier == null) {
                                instrumentPriceModifier = new InstrumentPriceModifier(getInstrumentName(), instrumentDTO.getValue());
                            } else {
                                Double multiplier = Double.sum(instrumentPriceModifier.getMultiplier(), instrumentDTO.getValue());
                                instrumentPriceModifier.setMultiplier(multiplier);
                            }
                            intrumentPriceModifierRepository.save(instrumentPriceModifier);
                            Thread.sleep(instrumentModificationTimeWaiting);
                        }
                    }
                } catch (Exception ex) {
                    // LOGGER
                }
            }
        };
        Thread thread = new Thread(task);
        thread.start();
    }

}
