/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.instrumentanalyzer.algorithm;

import com.instrumentanalyzer.dto.InstrumentDTO;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.springframework.beans.factory.annotation.Value;

/**
 *
 * @author mar
 */
public abstract class AbstractInstrumentAnalyzeAlgorithm {
    
    @Value("${instrument.modification.time.waiting}")
    protected Integer instrumentModificationTimeWaiting;

    protected ConcurrentLinkedQueue<InstrumentDTO> queue = new ConcurrentLinkedQueue<>();

    public void addToQueue(InstrumentDTO instrumentDTO) {
        queue.add(instrumentDTO);
    }

    protected abstract String getInstrumentName();

    protected abstract void enableAnalyzer();

}
