/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.instrumentanalyzer.algorithm;

import com.instrumentanalyzer.dto.InstrumentDTO;
import com.instrumentanalyzer.entity.InstrumentPriceModifier;
import com.instrumentanalyzer.repository.InstrumentPriceModifierRepository;
import java.text.ParseException;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 *
 * @author mar
 */
@Service
public class DefaultAlgorithmService extends AbstractInstrumentAnalyzeAlgorithm {

    @Autowired
    private InstrumentPriceModifierRepository intrumentPriceModifierRepository;

    @Value("${instrument.modification.time.waiting}")
    protected Integer instrumentModificationTimeWaiting;

    private ConcurrentHashMap<String, Integer> countMap;

    private ConcurrentHashMap<String, Double> sumMap;

    protected ConcurrentLinkedQueue<String> readyToCommitQueue = new ConcurrentLinkedQueue<>();

    @PostConstruct
    public void init() throws ParseException {
        countMap = new ConcurrentHashMap<>();
        sumMap = new ConcurrentHashMap<>();
        enableAnalyzer();
    }

    @Override
    protected String getInstrumentName() {
        return "DEFAULT";
    }

    @Override
    protected void enableAnalyzer() {
        Runnable addToMapsTask = () -> {
            System.out.println("Uruchomiono analizę " + getInstrumentName());
            while (true) {
                try {
                    if (!queue.isEmpty()) {
                        InstrumentDTO instrumentDTO = queue.peek();
                        String instrumentName = instrumentDTO.getInstrumentName();
                        Integer valueOfCounter = countMap.get(instrumentName);
                        if (countMap.containsKey(instrumentName)) {
                            if (valueOfCounter < 10) {
                                countMap.replace(instrumentName, ++valueOfCounter);
                                Double valueOfSum = sumMap.get(instrumentName);
                                valueOfSum = valueOfSum + instrumentDTO.getValue();
                                sumMap.replace(instrumentName, valueOfSum);
                                queue.poll();
                                if (valueOfCounter == 10) {
                                    readyToCommitQueue.add(instrumentName);
                                }
                            }
                        } else {
                            countMap.put(instrumentDTO.getInstrumentName(), 1);
                            sumMap.put(instrumentDTO.getInstrumentName(), instrumentDTO.getValue());
                            queue.poll();
                        }
                    }
                } catch (Exception ex) {
                    // LOGGER
                }
            }
        };
        Thread addToMapsThread = new Thread(addToMapsTask);
        addToMapsThread.start();

        Runnable getFromMapsTask = () -> {
            System.out.println("Uruchomiono analizę " + getInstrumentName());
            while (true) {
                try {
                    if (!readyToCommitQueue.isEmpty()) {
                        String instrumentName = readyToCommitQueue.poll();
                        Double valueOfSum = sumMap.get(instrumentName);

                        InstrumentPriceModifier instrumentPriceModifier = null;

                        instrumentPriceModifier = intrumentPriceModifierRepository.findByName(instrumentName);
                        if (instrumentPriceModifier == null) {
                            instrumentPriceModifier = new InstrumentPriceModifier(instrumentName, valueOfSum);
                        } else {
                            Double multiplier = Double.sum(instrumentPriceModifier.getMultiplier(), valueOfSum);
                            instrumentPriceModifier.setMultiplier(multiplier);
                        }
                        intrumentPriceModifierRepository.save(instrumentPriceModifier);
                        sumMap.replace(instrumentName, Double.valueOf(0));
                        countMap.replace(instrumentName, 0);
                        Thread.sleep(instrumentModificationTimeWaiting);
                    }
                } catch (Exception ex) {
                    // LOGGER
                }
            }
        };
        Thread getFromMapsThread = new Thread(getFromMapsTask);
        getFromMapsThread.start();
    }

}
