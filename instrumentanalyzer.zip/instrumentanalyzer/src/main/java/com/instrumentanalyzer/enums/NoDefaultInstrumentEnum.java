/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.instrumentanalyzer.enums;

/**
 *
 * @author mar
 */
public enum NoDefaultInstrumentEnum {
    
    INSTRUMENT_1("INSTRUMENT1"), INSTRUMENT_2("INSTRUMENT2"), INSTRUMENT_3("INSTRUMENT3");
    
    private final String description;
    
    NoDefaultInstrumentEnum(String description) {
        this.description = description;
    }   

    public String getDescription() {
        return description;
    }
    
    
    
}
