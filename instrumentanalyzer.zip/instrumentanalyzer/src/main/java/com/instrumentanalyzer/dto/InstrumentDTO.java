/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.instrumentanalyzer.dto;

import java.util.Date;

/**
 *
 * @author mar
 */
public class InstrumentDTO {
    
    private final String instrumentName;
    
    private final Date date;
    
    private final Double value;
    
    public InstrumentDTO(String instrumentName, Date date, Double value) {
        this.instrumentName = instrumentName;
        this.date = date;
        this.value = value;
    }

    public String getInstrumentName() {
        return instrumentName;
    }

    public Date getDate() {
        return date;
    }

    public double getValue() {
        return value;
    }   
    
}
